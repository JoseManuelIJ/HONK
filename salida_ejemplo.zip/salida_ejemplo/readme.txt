Se utilizó la siguiente ejecución:

./pipeline -c 3 -u 30 -n 80 -m mascara.txt -b

||  Imagen   ||  nearly black||
|| imagen_1   ||     NO       ||
|| imagen_2   ||     YES      ||
|| imagen_3   ||     NO       ||

